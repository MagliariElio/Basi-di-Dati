-- ------------------------------------
USE `BachecaElettronicadb`
-- ------------------------------------

call inserimentoNuovaCategoria('Immobili');

call inserimentoNuovaCategoria('Locali Commerciali');

call inserimentoNuovaCategoria('Motori');

call inserimentoNuovaCategoria('Auto');

call inserimentoNuovaCategoria('Moto');

call inserimentoNuovaCategoria('Accessori');

call inserimentoNuovaCategoria('Abbigliamento');

call inserimentoNuovaCategoria('Orologi e gioielli');

call inserimentoNuovaCategoria('Sport');

call inserimentoNuovaCategoria('Bici');

call inserimentoNuovaCategoria('Elettronica');

call inserimentoNuovaCategoria('Telefonia');

call inserimentoNuovaCategoria('Informatica computer');

call inserimentoNuovaCategoria('Videogames');

call inserimentoNuovaCategoria('Telecomunicazioni');

call inserimentoNuovaCategoria('Elettrodomestici');

call inserimentoNuovaCategoria('Fai da te');

