-- ------------------------------------
USE `BachecaElettronicadb`
-- ------------------------------------

INSERT INTO BachecaElettronicadb.Amministratore(Username, Password) VALUES ("amm1", md5("password"));

INSERT INTO BachecaElettronicadb.Amministratore(Username, Password) VALUES ("amm2", md5("password"));

INSERT INTO BachecaElettronicadb.Amministratore(Username, Password) VALUES ("amm3", md5("password"));

